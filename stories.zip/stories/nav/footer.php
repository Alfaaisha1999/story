<div class="container-fluid bg-dark text-light pl-3 ">
<div class="row pt-3">

<div class="col-md-12 col-sm-12 text-center">
    <div container>
<h4 id="about">About page</h4>
<p>This is my list of the best Japanese animation movie collection (not serials-just short story) and this is so far all the movies I could find... The list is not entirely in order and certainly not complete.  We all know the story: school, work, and other responsibilities in life are keeping you from more important tasks like finishing your favorite romance anime Please let me know if I missed any good movies</p>
</div>
</div>
<div class="col-md-12 text-center">
    <hr class="bg-light">
    <p class="mb-0">All right reserved &copy 2024</p>
    <p>made 💖 by Aisha sheikh</p>
</div>
</div>
</div>